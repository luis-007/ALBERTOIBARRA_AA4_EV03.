package com.actividadspring.actividadspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActividadspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
